package org.example;

public interface iBuff {
    public Double buffarPersonagem();
}
