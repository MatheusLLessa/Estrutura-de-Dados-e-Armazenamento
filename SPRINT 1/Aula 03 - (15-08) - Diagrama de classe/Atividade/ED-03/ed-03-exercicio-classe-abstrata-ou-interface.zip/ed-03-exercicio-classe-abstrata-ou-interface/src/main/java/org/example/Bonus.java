package org.example;

public interface Bonus {
    public Double getValorBonus();
}
